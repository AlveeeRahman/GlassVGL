#!/bin/sh
# Remove GlassVGL Icons and switch back to the desktop's default icon theme.
#   ./uninstall.sh [--system]
set -eu
DEST="${XDG_DATA_HOME:-$HOME/.local/share}/icons"; SUDO=""
[ "${1:-}" = "--system" ] && { DEST=/usr/share/icons; [ "$(id -u)" -eq 0 ] || SUDO=sudo; }
for t in GlassVGL GlassVGL-Dark GlassVGL-Sample GlassVGL-Sample-Dark; do
    [ -d "$DEST/$t" ] && $SUDO rm -rf "$DEST/$t" && echo "Removed $DEST/$t"
done
CFG="${XDG_CONFIG_HOME:-$HOME/.config}"
PREV="$CFG/glassvgl-icons/previous-icon-theme"
OLD=$(cat "$PREV" 2>/dev/null || true)
if command -v gsettings >/dev/null 2>&1 && gsettings list-schemas 2>/dev/null | grep -qx org.gnome.desktop.interface; then
    case "$(gsettings get org.gnome.desktop.interface icon-theme)" in
        *GlassVGL*) if [ -n "$OLD" ]; then gsettings set org.gnome.desktop.interface icon-theme "$OLD"; else gsettings reset org.gnome.desktop.interface icon-theme; fi
                    echo "Restored GNOME icon theme" ;;
    esac
fi
for f in "$CFG/gtk-3.0/settings.ini" "$CFG/gtk-4.0/settings.ini"; do
    [ -f "$f" ] || continue
    if [ -n "$OLD" ]; then sed -i "s|^gtk-icon-theme-name=GlassVGL.*|gtk-icon-theme-name=$OLD|" "$f"; else sed -i '/^gtk-icon-theme-name=GlassVGL/d' "$f"; fi
done
XS="$CFG/xsettingsd/xsettingsd.conf"
if [ -f "$XS" ]; then
    if [ -n "$OLD" ]; then sed -i "s|^Net/IconThemeName \"GlassVGL.*|Net/IconThemeName \"$OLD\"|" "$XS"; else sed -i '/^Net\/IconThemeName "GlassVGL/d' "$XS"; fi
    pkill -HUP -x xsettingsd 2>/dev/null || true
fi
for q in qt5ct qt6ct; do
    qf="$CFG/$q/$q.conf"; [ -f "$qf" ] || continue
    if [ -n "$OLD" ]; then sed -i "s|^icon_theme=GlassVGL.*|icon_theme=$OLD|" "$qf"; else sed -i '/^icon_theme=GlassVGL/d' "$qf"; fi
done
for d in "$CFG/lxsession/rpd-x/desktop.conf" "$CFG/lxsession/LXDE-pi/desktop.conf" "$CFG/lxsession/LXDE/desktop.conf"; do
    [ -f "$d" ] || continue
    if [ -n "$OLD" ]; then sed -i "s|^sNet/IconThemeName=GlassVGL.*|sNet/IconThemeName=$OLD|" "$d"; else sed -i '/^sNet\/IconThemeName=GlassVGL/d' "$d"; fi
done
rm -rf "$CFG/glassvgl-icons"
echo "Done."

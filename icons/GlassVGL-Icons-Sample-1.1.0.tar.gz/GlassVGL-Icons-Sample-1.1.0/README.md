# GlassVGL Icons Sample 1.1.0

A free taste of GlassVGL Icons: 25 frosted-glass icons for Linux desktops (Files, Terminal and the web browser app icons, five folders (plain, home, documents, downloads, pictures), trash, and text, image and PDF file icons), drawn for 16 to 64 px plus a scalable version, in a light theme (`GlassVGL-Sample`) and a dark theme (`GlassVGL-Sample-Dark`).

Everything else falls back to your current default theme (Adwaita).

## Install

```
./install.sh              # for this user, and switch to GlassVGL-Sample
./install.sh --dark       # same, but switch to GlassVGL-Sample-Dark
./install.sh --no-apply   # copy only
./uninstall.sh            # remove it and restore your previous icons
```

## The full pack

GlassVGL Icons has 397 colour icons in light and dark versions, plus 159 symbolic icons. It covers the GNOME apps on Ubuntu, the Raspberry Pi OS desktop apps, every folder, 116 file types and devices.

## Licence

The icons in this sample are licensed under Creative Commons Attribution 4.0 International (CC BY 4.0), in `LICENSE.txt`. You can share and adapt them, including commercially, as long as you credit "GlassVGL Icons by AlveeeRahman" and link to the licence. The install scripts are MIT licensed (`LICENSE-scripts.txt`).

The CC BY licence covers only the icons in this sample. The full GlassVGL Icons pack is sold separately under its own licence.

No brand logos are drawn. Ubuntu is a trademark of Canonical Ltd. Raspberry Pi is a trademark of Raspberry Pi Ltd. This sample is not affiliated with or endorsed by either company.

Copyright (c) 2026 AlveeeRahman.

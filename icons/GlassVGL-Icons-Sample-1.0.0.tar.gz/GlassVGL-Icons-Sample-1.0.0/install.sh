#!/bin/sh
# GlassVGL Icons installer for Ubuntu, Raspberry Pi OS and other freedesktop desktops.
#
#   ./install.sh            install for this user (~/.local/share/icons) and switch to GlassVGL
#   ./install.sh --dark     same, but switch to GlassVGL-Dark (full pack only)
#   ./install.sh --system   install for all users (/usr/share/icons, needs sudo)
#   ./install.sh --no-apply install only, keep the current icon theme
set -eu

HERE=$(cd "$(dirname "$0")" && pwd)
THEMES=""
for t in GlassVGL GlassVGL-Dark GlassVGL-Sample; do
    [ -f "$HERE/$t/index.theme" ] && THEMES="$THEMES $t"
done
[ -n "$THEMES" ] || { echo "No GlassVGL theme folder found next to install.sh" >&2; exit 1; }
DEST="${XDG_DATA_HOME:-$HOME/.local/share}/icons"
APPLY=${THEMES# }; APPLY=${APPLY%% *}
SUDO=""

for arg in "$@"; do
    case "$arg" in
        --dark) [ -f "$HERE/GlassVGL-Dark/index.theme" ] || { echo "This package has no dark theme" >&2; exit 2; }; APPLY=GlassVGL-Dark ;;
        --system) DEST=/usr/share/icons; [ "$(id -u)" -eq 0 ] || SUDO=sudo ;;
        --no-apply) APPLY="" ;;
        -h|--help) sed -n '2,8p' "$0"; exit 0 ;;
        *) echo "Unknown option: $arg" >&2; exit 2 ;;
    esac
done


# GlassVGL inherits Adwaita for everything it doesn't draw (symbolic icons and rare names)
found=""
for d in "${XDG_DATA_HOME:-$HOME/.local/share}/icons" /usr/local/share/icons /usr/share/icons; do
    [ -f "$d/Adwaita/index.theme" ] && found=1
done
[ -n "$found" ] || echo "Note: the Adwaita icon theme isn't installed. Install it for full coverage: sudo apt install adwaita-icon-theme"

$SUDO mkdir -p "$DEST"
for t in $THEMES; do
    $SUDO rm -rf "$DEST/$t"
    $SUDO cp -R "$HERE/$t" "$DEST/$t"
    if command -v gtk-update-icon-cache >/dev/null 2>&1; then
        $SUDO gtk-update-icon-cache -q -f -t "$DEST/$t" || true
    elif command -v gtk4-update-icon-cache >/dev/null 2>&1; then
        $SUDO gtk4-update-icon-cache -q -f -t "$DEST/$t" || true
    fi
    echo "Installed $t to $DEST/$t"
done

# older apps that only look in ~/.icons
if [ -z "$SUDO" ] && [ "$DEST" != "/usr/share/icons" ] && [ ! -e "$HOME/.icons" ]; then
    ln -s "$DEST" "$HOME/.icons" 2>/dev/null || true
fi

[ -n "$APPLY" ] || { echo "Done. Pick GlassVGL in your appearance settings."; exit 0; }

set_ini() {  # file key value
    f=$1; k=$2; v=$3
    mkdir -p "$(dirname "$f")"
    if [ -f "$f" ] && grep -q "^$k=" "$f"; then
        sed -i "s|^$k=.*|$k=$v|" "$f"
    elif [ -f "$f" ] && grep -q '^\[Settings\]' "$f"; then
        sed -i "/^\[Settings\]/a $k=$v" "$f"
    else
        printf '[Settings]\n%s=%s\n' "$k" "$v" >> "$f"
    fi
}

CFG="${XDG_CONFIG_HOME:-$HOME/.config}"
# remember the current theme once, so uninstall.sh can put it back
PREV="$CFG/glassvgl-icons/previous-icon-theme"
if [ ! -f "$PREV" ]; then
    old=""
    for d in rpd-x LXDE-pi; do
        [ -n "$old" ] || old=$(sed -n 's|^sNet/IconThemeName=||p' "$CFG/lxsession/$d/desktop.conf" 2>/dev/null | head -1)
    done
    [ -n "$old" ] || old=$(sed -n 's|^Net/IconThemeName *"\(.*\)"|\1|p' "$CFG/xsettingsd/xsettingsd.conf" /etc/xsettingsd/xsettingsd.conf 2>/dev/null | head -1)
    [ -n "$old" ] || old=$(sed -n 's/^gtk-icon-theme-name=//p' "$CFG/gtk-3.0/settings.ini" 2>/dev/null | head -1)
    if [ -z "$old" ] && command -v gsettings >/dev/null 2>&1; then
        old=$(gsettings get org.gnome.desktop.interface icon-theme 2>/dev/null | tr -d "'") || true
    fi
    case "$old" in GlassVGL*) old="" ;; esac
    mkdir -p "$(dirname "$PREV")"; printf '%s\n' "$old" > "$PREV"
fi
# GNOME, Ubuntu, Budgie, Cinnamon (gsettings), and Wayland GTK apps that read it
if command -v gsettings >/dev/null 2>&1 && gsettings list-schemas 2>/dev/null | grep -qx org.gnome.desktop.interface; then
    gsettings set org.gnome.desktop.interface icon-theme "$APPLY" && echo "Set GNOME icon theme to $APPLY"
fi
# GTK 3 and 4 settings files (Raspberry Pi OS, LXDE, labwc, Wayfire, Openbox)
set_ini "$CFG/gtk-3.0/settings.ini" gtk-icon-theme-name "$APPLY"
set_ini "$CFG/gtk-4.0/settings.ini" gtk-icon-theme-name "$APPLY"
# Raspberry Pi OS: xsettingsd feeds GTK apps under labwc/Wayfire; copy the system file first
XS="$CFG/xsettingsd/xsettingsd.conf"
if [ ! -f "$XS" ] && [ -f /etc/xsettingsd/xsettingsd.conf ]; then
    mkdir -p "$(dirname "$XS")"; cp /etc/xsettingsd/xsettingsd.conf "$XS"
fi
if [ -f "$XS" ]; then
    if grep -q '^Net/IconThemeName' "$XS"; then sed -i "s|^Net/IconThemeName.*|Net/IconThemeName \"$APPLY\"|" "$XS"
    else printf 'Net/IconThemeName "%s"\n' "$APPLY" >> "$XS"; fi
    echo "Updated $XS"
    pkill -HUP -x xsettingsd 2>/dev/null || true
fi
# Qt apps through qt5ct / qt6ct (Raspberry Pi OS sets icon_theme there)
for q in qt5ct qt6ct; do
    qf="$CFG/$q/$q.conf"
    if [ ! -f "$qf" ] && [ -f "/etc/xdg/$q/$q.conf" ]; then mkdir -p "$(dirname "$qf")"; cp "/etc/xdg/$q/$q.conf" "$qf"; fi
    [ -f "$qf" ] || continue
    if grep -q '^icon_theme=' "$qf"; then sed -i "s|^icon_theme=.*|icon_theme=$APPLY|" "$qf"
    elif grep -q '^\[Appearance\]' "$qf"; then sed -i "/^\[Appearance\]/a icon_theme=$APPLY" "$qf"
    else printf '[Appearance]\nicon_theme=%s\n' "$APPLY" >> "$qf"; fi
    echo "Updated $qf"
done
# LXDE sessions on X11 (Raspberry Pi OS rpd-x, older LXDE-pi, plain LXDE)
for d in "$CFG/lxsession/rpd-x/desktop.conf" "$CFG/lxsession/LXDE-pi/desktop.conf" "$CFG/lxsession/LXDE/desktop.conf"; do
    if [ -f "$d" ]; then
        if grep -q '^sNet/IconThemeName=' "$d"; then sed -i "s|^sNet/IconThemeName=.*|sNet/IconThemeName=$APPLY|" "$d"
        else sed -i "/^\[GTK\]/a sNet/IconThemeName=$APPLY" "$d"; fi
        echo "Updated $d"
    fi
done
# Xfce
if command -v xfconf-query >/dev/null 2>&1; then
    xfconf-query -c xsettings -p /Net/IconThemeName -s "$APPLY" 2>/dev/null || true
fi
echo "Done. If some windows keep the old icons, log out and back in."
echo "On Raspberry Pi OS, 'Restore defaults' in Appearance Settings switches the icons back; run this script again afterwards."
